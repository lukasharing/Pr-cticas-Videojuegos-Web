window.onload = () => {
	
	const game = new Frogger();
	
};