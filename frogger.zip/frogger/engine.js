class Frogger{
	
	constructor(canvas_id){		
		const canvas = document.getElementById("game");
		this.width = canvas.width = 550;
		this.height = canvas.height = 625;
		this.ctx = canvas.getContext("2d");
		
		this.draw = this.render_title;
		
		// Entities
		this.entities = new Array();
		
		// Sprites
		this.sprites = {
			"player":{
				sx: 0,
				sy: 0,
				sw: 0,
				sh: 55,
				bw: 40,
				bh: 340,
				frames: 7
			},
			"title":{
				sx: 0,
				sy: 395,
				sw: 280,
				sh: 170,
				bw: 40,
				bh: 170,
				frames: 1
			},
			"water":{
				sx: 160,
				sy: 226,
				sw: 50,
				sh: 50,
				frames: 1
			},
			"end":{
				sx: 96,
				sy: 226,
				sw: 50,
				sh: 50,
				frames: 1
			},
			"floor":{
				sx: 223,
				sy: 226,
				sw: 50,
				sh: 50,
				frames: 1
			},
			"start0":{
				sx: 223,
				sy: 226,
				sw: 50,
				sh: 50,
				frames: 1
			},
			"start1":{
				sx: 223,
				sy: 226,
				sw: 50,
				sh: 50,
				frames: 1
			}
		};
		this.sprite_sheet = document.getElementById("sheet");
		// Map
		this.map = document.createElement("canvas");
		this.map.width = 550;
		this.map.height = 625;
		this.map_heights = new Array(
			"water",
			"end",
			"floor"
		);
		
		
		//this.load_sprites("./json/sprites.json");
		this.render_background();
		this.play();
	};
	
	
	load_sprites(name){
		
		fetch(name).then(e => {
			e.json().then(b => {
				console.log(b);
			});
		});
	};
	
	render_sprite(ctx, name, x, y, frame){
		
		const sprite = this.sprites[name];
		if(typeof x === 'string'){
			switch(x){
				case "center": x = (this.width - sprite.sw) / 2; break;
				case "left"  : x = 0; break;
				case "right" : x = this.width - sprite.sw; break;
			}
		}
		
		if(typeof y === 'string'){
			switch(y){
				case "center": y = (this.height - sprite.sh) / 2; break;
				case "left"  : y = 0; break;
				case "right" : y = this.height - sprite.sh; break;
			}
		}
		
		ctx.drawImage(
			this.sprite_sheet,
			sprite.sx + (frame % sprite.frames) * sprite.sw,
			sprite.sy,
			sprite.sw,
			sprite.sh,
			x,
			y,
			sprite.sw,
			sprite.sh
		);
		
	};
	
	play(dt = 0.0){
		
		this.ctx.clearRect(0, 0, this.width, this.height);
		
		this.draw(dt);
		
		requestAnimationFrame((dt) => this.play(dt));
	};
	
	update(dt){
		this.entities.forEach( e => e.update(dt) );
	};
	
	render_title(dt){
		
		this.ctx.drawImage(this.map, 0, 0);
		this.render_sprite(this.ctx, "title", "center", 100, 0);
		
		this.ctx.font = "bold 30px Verdana";
		this.ctx.textAlign = "center";
		this.ctx.strokeStyle = "white";
		this.ctx.save();
			this.ctx.translate(this.width/2, 400);
			const anim_scl = 1.0 - Math.cos(dt / 200) / 8;
			this.ctx.scale(anim_scl, anim_scl)
			this.ctx.fillText("Press Space to play!", 0, 0);
			this.ctx.strokeText("Press Space to play!", 0, 0);
		this.ctx.restore();
	};
	
	render_game(){
		
		this.entities.forEach( e => e.render(ctx) );
		
	};
	
	render_background(){
		
		const map = [
			[+0, +0, +0, +0, +0, +0, +0, +0, +0, +0, +0],
			[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
			[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
			[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
			[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
			[+1, +1, +1, +1, +1, +1, +1, +1, +1, +1, +1],
			[+1, +1, +1, +1, +1, +1, +1, +1, +1, +1, +1],
			[+1, +1, +1, +1, +1, +1, +1, +1, +1, +1, +1],
			[+1, +1, +1, +1, +1, +1, +1, +1, +1, +1, +1],
			[+1, +1, +1, +1, +1, +1, +1, +1, +1, +1, +1],
			[+1, +1, +1, +1, +1, +1, +1, +1, +1, +1, +1],
			[+0, +0, +0, +0, +0, +0, +0, +0, +0, +0, +0]
		];
		
		
		const ctx = this.map.getContext("2d");
		for(let j = 0; j < map.length; ++j){
			for(let i = 0; i < map[0].length; ++i){
				const name = this.map_heights[map[j][i] + 1];
				name += (name == "start") ? (i & 1) : "";
				
				this.render_sprite(
					ctx, 
					name,
					i * 50,
					j * 50,
					0
				);
			}
		}
		
		
	};
	
}